const { usersModel } = require('./userModel.js');

module.exports = {
	usersModel,
};
